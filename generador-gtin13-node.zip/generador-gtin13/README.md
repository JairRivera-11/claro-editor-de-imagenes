# Generador GTIN-13 / EAN-13 para Mexico

Proyecto funcional sin dependencias externas. Requiere Node.js 20 o superior.

## 1. Ejecutar en VS Code

1. Descomprime el ZIP en una carpeta.
2. Abre esa carpeta en VS Code.
3. En Terminal, comprueba `node --version` (debe ser >=20).
4. Genera diez codigos de simulacion:

```bash
node gtin13.mjs generar --cantidad 10 --salida mis_codigos.csv
```

Tambien puedes ejecutar `npm start` (genera 10 codigos con un CSV nuevo).
No necesitas `npm install` porque no hay dependencias externas.

## 2. Comandos utiles

```bash
# Simulacion (modo predeterminado, prefijo 750):
node gtin13.mjs generar --cantidad 100 --salida prueba_100.csv

# Primera generacion con inicio elegido (ejemplo interno):
node gtin13.mjs generar --cantidad 10 --inicial 1000 --salida prueba_inicio.csv

# Prefijo de empresa oficialmente licenciado y confirmado por ti:
node gtin13.mjs generar --modo oficial --prefijo 75012345678 --confirmar-autorizacion --cantidad 5 --salida oficial.csv

# Cambiar la ubicacion del JSON persistente:
node gtin13.mjs generar --cantidad 10 --historial ./datos/historial.json --salida ./datos/salida.csv

# CSV plano para sistemas/ETL (Excel debe importar esa columna como Texto):
node gtin13.mjs generar --cantidad 10 --formato plano --salida integracion.csv

# Reexportar exactamente el mismo lote sin emitir codigos nuevos:
node gtin13.mjs exportar --lote UUID_DEL_LOTE --salida reexportado.csv

# Ver todas las opciones:
node gtin13.mjs ayuda
```

IMPORTANTE: el prefijo 75012345678 del ejemplo es ilustrativo, NO una licencia
verificada. El modo `oficial` solo acepta tu declaracion de autorizacion y NO
consulta los registros de GS1. Nunca uses prefijos inventados comercialmente.

## 3. Modos

- `simulacion`: prefijo 750 predeterminado (hasta 11 digitos de prefijo de prueba).
  Los numeros pueden coincidir con identificadores reales de terceros. No usar
  para productos comerciales, marketplaces ni redes de distribucion.
- `oficial`: exige el prefijo completo que indiques (750 + prefijo de empresa,
  4 a 12 digitos en total) y `--confirmar-autorizacion`. Si el prefijo mide
  12 digitos, la capacidad es exactamente un GTIN-13 (sin referencia adicional).

La referencia se forma con los digitos disponibles hasta completar los primeros
12 del GTIN-13. El digito numero 13 se calcula con modulo 10 de GS1.

## 4. Archivos y conservacion de historial

El programa mantiene:

- `historial_gtin13.json`: historial completo, configuraciones, lotes y SHA-256.
- `historial_gtin13.json.inicializado`: marca que evita reiniciar si desaparece
  accidentalmente el JSON principal.
- `historial_gtin13.json.lock`: carpeta temporal de exclusividad, activa solo
  durante una operacion (se elimina al concluir correctamente).

Si cambias `--historial`, cambia tambien el directorio del registro.
**Usa SIEMPRE la misma ruta de historial para todos tus lotes y modos.**
Respaldar conjuntamente JSON y su marca. No borres ni edites estos archivos.

Se usa escritura temporal, sincronizacion y renombrado del JSON. Para los CSV
se crea primero un archivo temporal y luego se publica con un enlace atomico
sin sobrescribir salidas existentes. Ante una caida durante la publicacion,
puede quedar un lote reservado en JSON sin CSV: utiliza `exportar --lote` para
recuperarlo. La referencia no se reutilizara.

Si una ejecucion se interrumpe de forma brusca, puede quedar `*.lock`. Comprueba
que no haya ningun proceso ejecutandose antes de quitar manualmente ese candado.

Los errores del historial o de su suma SHA-256 detienen la generacion. SHA-256
sirve para detectar alteraciones accidentales, no es una firma criptografica
contra alguien que controle los archivos.

## 5. Excel y formato CSV

El CSV predeterminado (formato `excel`) usa una celda como `="7500000000016"`.
Al abrirlo directamente en Excel, se muestra como texto con 13 digitos sin
notacion cientifica ni perdida de ceros. Los valores son digitos validados;
no hay formulas suministradas por un usuario.

Para integraciones que requieren una celda CSV con solo los 13 caracteres
numericos, elige `--formato plano`. Al importarlo en Excel, configura la columna
`gtin_13` como Texto para conservar posibles ceros iniciales.

Cada CSV contiene los encabezados `consecutivo,gtin_13`; el consecutivo se
reinicia en 1 por lote y no es parte del GTIN.

## 6. Pruebas automaticas

```bash
npm test
```

Se prueban ejemplos oficiales GS1 (GTIN `9521101530001`, ISSN `9770174736005`,
ISBN `9780471384298`), longitud, checksum, orden, capacidad, reinicio,
unicidad, colisiones, JSON corrupto, SHA-256, bloqueo entre procesos,
CSV plano/Excel, reexportacion y el caso de prefijo de 12 digitos.

## 7. Limitaciones y advertencias

- La unicidad solo esta garantizada respecto de los codigos presentes en un
  historial JSON unico y conservado. No se consultan asignaciones mundiales.
- Modo oficial NO valida la titularidad del prefijo ni revisa GTIN previamente
  asignados en otros sistemas de la empresa. Verifica ese inventario antes
  de emitir codigos para un catalogo real.
- Un codigo matematicamente valido no representa una asignacion oficial GS1.
- El almacenamiento JSON local es razonable para volumen moderado. Para millones
  de codigos, multiples servidores o comparticion en red, conviene una base
  transaccional con respaldos y restriccion de unicidad.
- Si desaparecen tanto el JSON como su marca, el programa no tiene forma
  de detectar una asignacion anterior. Protege ambos y manten respaldos.

## 8. Ejemplos incluidos

En `ejemplos/` tienes una ejecucion real con 10 codigos, el JSON resultante
con su SHA-256 y los CSV en formato Excel y plano.

Fuentes GS1 utilizadas para los ejemplos del calculo:
- https://ref.gs1.org/guidelines/2d-in-retail/1.1.0/
- https://support.gs1.org/support/solutions/articles/43000734320-how-is-an-issn-used-in-a-gs1-barcode-
- https://support.gs1.org/support/solutions/articles/43000734165-how-is-an-isbn-used-in-a-gs1-barcode-
- https://www.gs1mexico.org/preguntas-frecuentes
