#!/usr/bin/env node
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const DIGITOS = /^\d+$/;
const MODOS = new Set(['simulacion', 'oficial']);
const FORMATOS = new Set(['excel', 'plano']);

export function digitoVerificador(base12) {
  if (typeof base12 !== 'string' || !/^\d{12}$/.test(base12)) {
    throw new Error('El calculo requiere exactamente 12 digitos numericos.');
  }
  let suma = 0;
  for (let i = 0; i < 12; i++) {
    suma += Number(base12[i]) * (i % 2 === 0 ? 1 : 3);
  }
  return String((10 - (suma % 10)) % 10);
}

export function validarGTIN13(codigo) {
  return typeof codigo === 'string' && /^\d{13}$/.test(codigo)
    && digitoVerificador(codigo.slice(0, 12)) === codigo[12];
}

export function formarGTIN13(prefijo, referencia) {
  const base = prefijo + referencia;
  return base + digitoVerificador(base);
}

function claveDe(modo, prefijo) {
  return `${modo}:${prefijo}`;
}

function anchoReferencia(prefijo) {
  return 12 - prefijo.length;
}

function rellenar(numero, ancho) {
  if (ancho === 0) return ''; // Prefijo de 12 digitos: un unico GTIN posible.
  return String(numero).padStart(ancho, '0');
}

function enteroSeguro(valor, etiqueta, minimo = 0) {
  if (typeof valor !== 'string' && typeof valor !== 'number') {
    throw new Error(`${etiqueta}: introduce un entero valido.`);
  }
  const texto = String(valor);
  if (!DIGITOS.test(texto) || !Number.isSafeInteger(Number(texto)) || Number(texto) < minimo) {
    throw new Error(`${etiqueta}: introduce un entero mayor o igual a ${minimo}.`);
  }
  return Number(texto);
}

function validarPrefijo(modo, prefijo) {
  if (!MODOS.has(modo)) throw new Error('Modo invalido: usa simulacion u oficial.');
  const minimo = modo === 'oficial' ? 4 : 3;
  const maximo = modo === 'oficial' ? 12 : 11;
  if (typeof prefijo !== 'string' || !DIGITOS.test(prefijo)
      || !prefijo.startsWith('750') || prefijo.length < minimo || prefijo.length > maximo) {
    throw new Error(`Prefijo invalido: debe comenzar con 750 y tener entre ${minimo} y ${maximo} digitos.`);
  }
  // Con 12 digitos de prefijo oficial hay un GTIN posible y referencia vacia.
  return prefijo;
}

function validarOpcionesGeneracion(op) {
  const modo = op.modo ?? 'simulacion';
  const prefijo = op.prefijo ?? (modo === 'simulacion' ? '750' : undefined);
  if (modo === 'oficial' && !prefijo) {
    throw new Error('Modo oficial: introduce el prefijo completo de empresa con --prefijo.');
  }
  validarPrefijo(modo, prefijo);
  if (modo === 'oficial' && op.confirmarAutorizacion !== true) {
    throw new Error('Modo oficial: declara que el prefijo es tuyo con --confirmar-autorizacion. Esto no verifica la licencia ante GS1.');
  }
  const cantidad = enteroSeguro(op.cantidad ?? '10', 'Cantidad', 1);
  const inicial = op.inicial === undefined ? undefined : enteroSeguro(op.inicial, 'Secuencia inicial');
  const formato = op.formato ?? 'excel';
  if (!FORMATOS.has(formato)) throw new Error('Formato CSV invalido: usa excel o plano.');
  const historial = path.resolve(op.historial ?? 'historial_gtin13.json');
  const salida = path.resolve(op.salida ?? nombreSalida());
  comprobarRutas(historial, salida);
  return { modo, prefijo, cantidad, inicial, formato, historial, salida };
}

function comprobarRutas(historial, salida) {
  const reservadas = [historial, `${historial}.inicializado`, `${historial}.lock`];
  if (reservadas.includes(salida)) {
    throw new Error('La salida CSV no puede coincidir con el historial, su marca ni su candado.');
  }
}

function nombreSalida() {
  const fecha = new Date().toISOString().replace(/[-:.]/g, '').replace('Z', '');
  return `gtin13_${fecha}_${randomUUID().slice(0, 8)}.csv`;
}

function estadoVacio() {
  return { version: 1, configuraciones: {}, historial: [] };
}

function hashEstado(estado) {
  return createHash('sha256').update(JSON.stringify(estado), 'utf8').digest('hex');
}

function serializarEstado(estado) {
  return JSON.stringify({ ...estado, integridad_sha256: hashEstado(estado) }, null, 2) + '\n';
}

async function existe(ruta) {
  try {
    await fs.lstat(ruta);
    return true;
  } catch (e) {
    if (e.code === 'ENOENT') return false;
    throw e;
  }
}

function validarEstructura(estado) {
  const error = (detalle) => { throw new Error(`Historial inconsistente: ${detalle}. No se modifico nada.`); };
  if (estado.version !== 1 || !estado.configuraciones
      || typeof estado.configuraciones !== 'object' || Array.isArray(estado.configuraciones)
      || !Array.isArray(estado.historial)) error('esquema invalido');
  const contadores = new Map();
  for (const [clave, cfg] of Object.entries(estado.configuraciones)) {
    if (!cfg || !MODOS.has(cfg.modo)) error('modo de configuracion invalido');
    try { validarPrefijo(cfg.modo, cfg.prefijo); } catch { error('prefijo almacenado invalido'); }
    if (claveDe(cfg.modo, cfg.prefijo) !== clave) error('clave de configuracion incorrecta');
    const ancho = anchoReferencia(cfg.prefijo);
    if (typeof cfg.secuencia_inicial !== 'string'
        || !new RegExp(`^\\d{${ancho}}$`).test(cfg.secuencia_inicial)
        || typeof cfg.ultima_referencia !== 'string'
        || !new RegExp(`^\\d{${ancho}}$`).test(cfg.ultima_referencia)
        || Number(cfg.ultima_referencia) < Number(cfg.secuencia_inicial)) error('rango de configuracion invalido');
    if (!Number.isFinite(Date.parse(cfg.fecha_inicio))
        || !Number.isFinite(Date.parse(cfg.fecha_ultima_generacion))) error('fechas de configuracion invalidas');
    contadores.set(clave, 0);
  }
  const vistos = new Set();
  for (const registro of estado.historial) {
    if (!registro || typeof registro !== 'object') error('registro nulo o malformado');
    const clave = claveDe(registro.modo, registro.prefijo);
    const cfg = estado.configuraciones[clave];
    if (!cfg) error('registro sin configuracion');
    const ancho = anchoReferencia(registro.prefijo);
    if (typeof registro.referencia !== 'string'
        || !new RegExp(`^\\d{${ancho}}$`).test(registro.referencia)) error('referencia malformada');
    if (!validarGTIN13(registro.gtin_13)
        || formarGTIN13(registro.prefijo, registro.referencia) !== registro.gtin_13) {
      error('GTIN o digito verificador incorrecto');
    }
    if (vistos.has(registro.gtin_13)) error('codigo duplicado');
    vistos.add(registro.gtin_13);
    if (typeof registro.lote !== 'string' || registro.lote.length < 1
        || !Number.isFinite(Date.parse(registro.fecha_generacion))) error('metadatos invalidos');
    const esperado = Number(cfg.secuencia_inicial) + contadores.get(clave);
    if (Number(registro.referencia) !== esperado) error('secuencia alterada o reutilizada');
    contadores.set(clave, contadores.get(clave) + 1);
  }
  for (const [clave, cfg] of Object.entries(estado.configuraciones)) {
    const num = contadores.get(clave);
    if (num === 0 || Number(cfg.ultima_referencia) !== Number(cfg.secuencia_inicial) + num - 1) {
      error('ultima referencia no coincide con el historial');
    }
  }
}

export async function leerHistorial(archivo) {
  const historial = path.resolve(archivo);
  let texto;
  try {
    texto = await fs.readFile(historial, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') throw new Error(`No se pudo leer el historial: ${e.message}`);
    if (await existe(`${historial}.inicializado`)) {
      throw new Error('Falta el JSON, pero existe su marca de inicializacion. Se detiene para evitar reiniciar la secuencia.');
    }
    return estadoVacio();
  }
  let completo;
  try { completo = JSON.parse(texto); }
  catch { throw new Error('Historial JSON corrupto. No se genero ningun codigo.'); }
  if (!completo || Array.isArray(completo) || typeof completo !== 'object') {
    throw new Error('Historial JSON invalido. No se modifico nada.');
  }
  const { integridad_sha256, ...estado } = completo;
  if (typeof integridad_sha256 !== 'string' || hashEstado(estado) !== integridad_sha256) {
    throw new Error('Fallo la verificacion SHA-256 del historial. No se modifico nada.');
  }
  validarEstructura(estado);
  return estado;
}

async function fsyncCarpeta(carpeta) {
  let manejador;
  try {
    manejador = await fs.open(carpeta, 'r');
    await manejador.sync();
  } catch (e) {
    if (!['EINVAL', 'ENOTSUP', 'EISDIR', 'EPERM', 'EACCES'].includes(e.code)) throw e;
  } finally {
    await manejador?.close();
  }
}

async function escribirTemporal(ruta, contenido) {
  const temporal = `${ruta}.tmp-${randomUUID()}`;
  let manejador;
  try {
    manejador = await fs.open(temporal, 'wx', 0o600);
    await manejador.writeFile(contenido, 'utf8');
    await manejador.sync();
    await manejador.close();
    manejador = undefined;
    return temporal;
  } catch (e) {
    await manejador?.close().catch(() => {});
    await fs.rm(temporal, { force: true }).catch(() => {});
    throw e;
  }
}

async function guardarHistorial(historial, estado) {
  const temporal = await escribirTemporal(historial, serializarEstado(estado));
  try {
    await fs.rename(temporal, historial);
    await fsyncCarpeta(path.dirname(historial));
  } finally {
    await fs.rm(temporal, { force: true }).catch(() => {});
  }
  const marca = `${historial}.inicializado`;
  if (!(await existe(marca))) {
    let archivo;
    try {
      archivo = await fs.open(marca, 'wx', 0o600);
      await archivo.writeFile(`Historial creado. No borres ${historial}.\n`, 'utf8');
      await archivo.sync();
    } catch (e) {
      if (e.code !== 'EEXIST') throw e;
    } finally {
      await archivo?.close();
    }
  }
}

async function conCandado(historial, accion) {
  const candado = `${historial}.lock`;
  try {
    await fs.mkdir(candado, { mode: 0o700 });
  } catch (e) {
    if (e.code === 'EEXIST') {
      throw new Error(`Otra ejecucion mantiene el candado: ${candado}. Si hubo una caida, verifica que no siga activa antes de retirarlo manualmente.`);
    }
    throw e;
  }
  try {
    await fs.writeFile(path.join(candado, 'propietario.json'),
      JSON.stringify({ pid: process.pid, fecha: new Date().toISOString() }, null, 2), 'utf8');
    return await accion();
  } finally {
    await fs.rm(candado, { recursive: true, force: true });
  }
}

export function crearCSV(registros, formato = 'excel') {
  if (!FORMATOS.has(formato)) throw new Error('Formato CSV invalido.');
  const lineas = registros.map((r, i) => {
    if (!validarGTIN13(r.gtin_13)) throw new Error('No se exporta un GTIN invalido.');
    // Excel interpreta ="750..." como una cadena exacta, sin notacion cientifica.
    // Solo se interpolan 13 digitos ya validados: no existe entrada de formulas arbitrarias.
    const celda = formato === 'excel' ? `"=""${r.gtin_13}"""` : r.gtin_13;
    return `${i + 1},${celda}`;
  });
  return '\uFEFF' + ['consecutivo,gtin_13', ...lineas].join('\r\n') + '\r\n';
}

async function publicarCSV(temporal, salida) {
  // link() crea el destino de forma atomica SIN sobrescribir un archivo preexistente.
  await fs.link(temporal, salida);
  await fsyncCarpeta(path.dirname(salida));
}

export async function generar(op = {}) {
  const p = validarOpcionesGeneracion(op);
  return conCandado(p.historial, async () => {
    const estado = await leerHistorial(p.historial);
    if (await existe(p.salida)) throw new Error('El CSV de salida ya existe; usa otra ruta para evitar sobrescribirlo.');
    const clave = claveDe(p.modo, p.prefijo);
    const cfg = estado.configuraciones[clave];
    if (cfg && p.inicial !== undefined) {
      throw new Error('La secuencia inicial solo puede indicarse en la primera generacion de cada modo y prefijo.');
    }
    const ancho = anchoReferencia(p.prefijo);
    const maximo = 10 ** ancho - 1;
    const inicio = cfg ? Number(cfg.ultima_referencia) + 1 : (p.inicial ?? (ancho === 0 ? 0 : 1));
    const disponibles = Math.max(0, maximo - inicio + 1);
    if (p.cantidad > disponibles) {
      throw new Error(`Rango agotado o insuficiente. Disponibles: ${disponibles}; solicitados: ${p.cantidad}; maximo: ${maximo}.`);
    }
    const usados = new Set(estado.historial.map((r) => r.gtin_13));
    const fecha = new Date().toISOString();
    const lote = randomUUID();
    const nuevos = [];
    for (let i = 0; i < p.cantidad; i++) {
      const referencia = rellenar(inicio + i, ancho);
      const gtin_13 = formarGTIN13(p.prefijo, referencia);
      if (!validarGTIN13(gtin_13) || usados.has(gtin_13)) {
        throw new Error(`Colision detectada con otro registro: ${gtin_13}. No se asigno ningun codigo de este lote.`);
      }
      usados.add(gtin_13);
      nuevos.push({ gtin_13, modo: p.modo, prefijo: p.prefijo,
        referencia, lote, fecha_generacion: fecha });
    }
    const siguiente = structuredClone(estado);
    siguiente.configuraciones[clave] = cfg
      ? { ...cfg, ultima_referencia: nuevos.at(-1).referencia, fecha_ultima_generacion: fecha }
      : { modo: p.modo, prefijo: p.prefijo, secuencia_inicial: nuevos[0].referencia,
        ultima_referencia: nuevos.at(-1).referencia, fecha_inicio: fecha,
        fecha_ultima_generacion: fecha };
    siguiente.historial.push(...nuevos);
    const temporal = await escribirTemporal(p.salida, crearCSV(nuevos, p.formato));
    try {
      // Se reserva primero en el historial: nunca se entrega un CSV no registrado.
      await guardarHistorial(p.historial, siguiente);
      try {
        await publicarCSV(temporal, p.salida);
      } catch (e) {
        throw new Error(`Lote ${lote} reservado en JSON, pero no se pudo publicar el CSV: ${e.message}. Recupera con: node gtin13.mjs exportar --lote ${lote} --salida otro.csv`);
      }
      return { lote, registros: nuevos, salida: p.salida, historial: p.historial, formato: p.formato };
    } finally {
      await fs.rm(temporal, { force: true }).catch(() => {});
    }
  });
}

export async function exportarLote(op = {}) {
  const historial = path.resolve(op.historial ?? 'historial_gtin13.json');
  const salida = path.resolve(op.salida ?? nombreSalida());
  const formato = op.formato ?? 'excel';
  if (!FORMATOS.has(formato)) throw new Error('Formato CSV invalido.');
  if (typeof op.lote !== 'string' || !/^[0-9a-f-]{36}$/.test(op.lote)) {
    throw new Error('Indica --lote con el identificador UUID guardado en el historial.');
  }
  comprobarRutas(historial, salida);
  return conCandado(historial, async () => {
    const estado = await leerHistorial(historial);
    const registros = estado.historial.filter((x) => x.lote === op.lote);
    if (!registros.length) throw new Error('No se encontro el lote solicitado.');
    if (await existe(salida)) throw new Error('El CSV de salida ya existe; no se sobrescribira.');
    const temporal = await escribirTemporal(salida, crearCSV(registros, formato));
    try { await publicarCSV(temporal, salida); }
    finally { await fs.rm(temporal, { force: true }).catch(() => {}); }
    return { lote: op.lote, registros, salida, historial, formato };
  });
}

function leerArgumentos(args) {
  const copia = [...args];
  const comando = copia[0] && !copia[0].startsWith('--') ? copia.shift() : 'generar';
  if (comando === '--ayuda' || comando === 'ayuda') return { comando: 'ayuda', opciones: {} };
  if (!['generar', 'exportar'].includes(comando)) throw new Error('Comando desconocido. Usa generar, exportar o ayuda.');
  const opciones = {};
  const nombres = { '--cantidad': 'cantidad', '--modo': 'modo', '--prefijo': 'prefijo',
    '--inicial': 'inicial', '--historial': 'historial', '--salida': 'salida',
    '--formato': 'formato', '--lote': 'lote' };
  for (let i = 0; i < copia.length; i++) {
    const arg = copia[i];
    if (arg === '--ayuda') return { comando: 'ayuda', opciones: {} };
    if (arg === '--confirmar-autorizacion') {
      if (opciones.confirmarAutorizacion) throw new Error('Parametro repetido: --confirmar-autorizacion.');
      opciones.confirmarAutorizacion = true;
      continue;
    }
    if (!(arg in nombres)) throw new Error(`Parametro desconocido: ${arg}`);
    if (i + 1 >= copia.length || copia[i + 1].startsWith('--')) throw new Error(`Falta valor para ${arg}.`);
    if (opciones[nombres[arg]] !== undefined) throw new Error(`Parametro repetido: ${arg}.`);
    opciones[nombres[arg]] = copia[++i];
  }
  if (comando === 'exportar'
      && ['cantidad', 'modo', 'prefijo', 'inicial', 'confirmarAutorizacion'].some((n) => opciones[n] !== undefined)) {
    throw new Error('exportar solo admite --lote, --historial, --salida y --formato.');
  }
  if (comando === 'generar' && opciones.lote !== undefined) {
    throw new Error('--lote solo es valido para exportar.');
  }
  return { comando, opciones };
}

function ayuda() {
  console.log(`GENERADOR GTIN-13 / EAN-13 (Node.js 20+)

Generar 10 codigos de simulacion (prefijo 750 por defecto):
  node gtin13.mjs generar --cantidad 10 --salida prueba.csv

Generar con un prefijo GS1 licenciado (solo si tienes autorizacion):
  node gtin13.mjs generar --modo oficial --prefijo TU_PREFIJO_NUMERICO --confirmar-autorizacion --cantidad 10 --salida oficial.csv

Recuperar un CSV desde un lote del historial:
  node gtin13.mjs exportar --lote UUID_DEL_LOTE --salida recuperado.csv

Opciones:
  --cantidad N                 Cantidad (por defecto: 10)
  --modo simulacion|oficial     Por defecto: simulacion
  --prefijo DIGITOS            Por defecto: 750 en simulacion
  --confirmar-autorizacion     Declaracion requerida en modo oficial
  --inicial N                  Solo en la primera generacion de ese modo/prefijo
  --historial RUTA             Por defecto: historial_gtin13.json
  --salida RUTA                CSV nuevo (nunca se sobrescribe)
  --formato excel|plano        Por defecto: excel; plano para integraciones

Aviso: un GTIN con digito correcto NO acredita asignacion GS1.
Los codigos de simulacion NO se deben comercializar.`);
}

async function ejecutarCLI() {
  const { comando, opciones } = leerArgumentos(process.argv.slice(2));
  if (comando === 'ayuda') { ayuda(); return; }
  const resultado = comando === 'exportar' ? await exportarLote(opciones) : await generar(opciones);
  console.log(`Operacion completada: ${resultado.registros.length} codigos.`);
  console.log(`Lote: ${resultado.lote}`);
  console.log(`CSV: ${resultado.salida}`);
  console.log(`Historial: ${resultado.historial}`);
  if (comando === 'generar' && (opciones.modo ?? 'simulacion') === 'simulacion') {
    console.log('AVISO: SIMULACION. Sin asignacion oficial GS1; uso interno exclusivamente.');
  } else if (comando === 'generar') {
    console.log('AVISO: Se uso el prefijo declarado por el usuario; no se verifico ante GS1.');
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  ejecutarCLI().catch((e) => { console.error(`ERROR: ${e.message}`); process.exitCode = 1; });
}
