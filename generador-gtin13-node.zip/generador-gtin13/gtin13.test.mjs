import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { digitoVerificador, validarGTIN13, formarGTIN13,
  generar, leerHistorial, exportarLote, crearCSV } from './gtin13.mjs';

async function carpetaTemporal(t) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'test-gtin13-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  return dir;
}

function rutas(dir, nombre) {
  return { historial: path.join(dir, 'historial.json'), salida: path.join(dir, `${nombre}.csv`) };
}

function lanzar(args, cwd) {
  const script = fileURLToPath(new URL('./gtin13.mjs', import.meta.url));
  return new Promise((resolve, reject) => {
    const hijo = spawn(process.execPath, [script, ...args], { cwd });
    let stdout = '';
    let stderr = '';
    hijo.stdout.on('data', (x) => { stdout += x; });
    hijo.stderr.on('data', (x) => { stderr += x; });
    hijo.on('error', reject);
    hijo.on('close', (codigo) => resolve({ codigo, stdout, stderr }));
  });
}

test('ejemplos oficiales de GS1 para el digito verificador', () => {
  // GS1: 2D Barcodes at Retail POS Guidelines, tabla 4-2.
  assert.equal(digitoVerificador('952110153000'), '1');
  assert.equal(validarGTIN13('9521101530001'), true);
  // GS1 Global: ejemplos de conversion de ISSN e ISBN a GTIN-13.
  assert.equal(digitoVerificador('977017473600'), '5');
  assert.equal(validarGTIN13('9770174736005'), true);
  assert.equal(digitoVerificador('978047138429'), '8');
  assert.equal(validarGTIN13('9780471384298'), true);
  assert.equal(validarGTIN13('9770174736006'), false);
  assert.equal(validarGTIN13('952110153000'), false);
  assert.equal(validarGTIN13('952110153000A'), false);
  assert.throws(() => digitoVerificador('75012'));
});

test('genera 10, reanuda 5, conserva orden, longitud, unicidad y checksum', async (t) => {
  const dir = await carpetaTemporal(t);
  const a = await generar({ cantidad: 10, ...rutas(dir, 'lote1') });
  const b = await generar({ cantidad: 5, ...rutas(dir, 'lote2') });
  const registros = [...a.registros, ...b.registros];
  assert.equal(registros.length, 15);
  assert.equal(new Set(registros.map((r) => r.gtin_13)).size, 15);
  assert.deepEqual(registros.map((r) => r.referencia),
    Array.from({ length: 15 }, (_, i) => String(i + 1).padStart(9, '0')));
  assert.ok(registros.every((r) => r.gtin_13.length === 13 && validarGTIN13(r.gtin_13)));
  assert.ok(registros.every((r) => r.gtin_13.startsWith('750')));
  const estado = await leerHistorial(path.join(dir, 'historial.json'));
  assert.equal(estado.historial.length, 15);
  assert.equal(estado.configuraciones['simulacion:750'].ultima_referencia, '000000015');
  const csv = await fs.readFile(b.salida, 'utf8');
  assert.match(csv, /consecutivo,gtin_13/);
  assert.match(csv, /1,"=""750\d{10}"""/);
  await assert.rejects(() => generar({ cantidad: 1, ...rutas(dir, 'lote2') }), /ya existe/);
});

test('modo plano exporta 13 digitos reales y no formulas', async (t) => {
  const dir = await carpetaTemporal(t);
  const resultado = await generar({ cantidad: 2, formato: 'plano', inicial: 0,
    prefijo: '75012345678', ...rutas(dir, 'plano') });
  const csv = await fs.readFile(resultado.salida, 'utf8');
  assert.ok(csv.includes(`1,${resultado.registros[0].gtin_13}\r\n`));
  assert.equal(resultado.registros[0].referencia, '0');
  assert.ok(!csv.includes('="'));
});

test('rechaza agotamiento sin asignaciones parciales', async (t) => {
  const dir = await carpetaTemporal(t);
  const op = { prefijo: '75012345678', inicial: 8, cantidad: 2, ...rutas(dir, 'capacidad') };
  await generar(op);
  await assert.rejects(() => generar({ prefijo: op.prefijo, cantidad: 1,
    ...rutas(dir, 'sin-capacidad') }), /Disponibles: 0/);
  const estado = await leerHistorial(op.historial);
  assert.equal(estado.historial.length, 2);
  assert.equal(await fs.readdir(dir).then((a) => a.filter((n) => n.endsWith('.csv')).length), 1);
});

test('rechaza cantidades, prefijos y modo oficial sin declaracion de autorizacion', async (t) => {
  const dir = await carpetaTemporal(t);
  const r = rutas(dir, 'invalidos');
  await assert.rejects(() => generar({ cantidad: 0, ...r }), /Cantidad/);
  await assert.rejects(() => generar({ cantidad: '1.5', ...r }), /Cantidad/);
  await assert.rejects(() => generar({ prefijo: '7511234', ...r }), /Prefijo/);
  await assert.rejects(() => generar({ modo: 'oficial', prefijo: '75012345', ...r }), /--confirmar-autorizacion/);
  await assert.rejects(() => generar({ modo: 'oficial', prefijo: '750', confirmarAutorizacion: true, ...r }), /Prefijo/);
});

test('evita collision entre modos y prefijos incluso si el checksum coincide', async (t) => {
  const dir = await carpetaTemporal(t);
  const primera = await generar({ inicial: 123456780, cantidad: 1, ...rutas(dir, 'sim') });
  assert.equal(primera.registros[0].gtin_13, formarGTIN13('75012345678', '0'));
  await assert.rejects(() => generar({ modo: 'oficial', prefijo: '75012345678',
    confirmarAutorizacion: true, inicial: 0, cantidad: 1,
    ...rutas(dir, 'ofi') }), /Colision detectada/);
  const estado = await leerHistorial(path.join(dir, 'historial.json'));
  assert.equal(estado.historial.length, 1);
});

test('impide cambiar la secuencia inicial de un prefijo usado', async (t) => {
  const dir = await carpetaTemporal(t);
  await generar({ inicial: 10, cantidad: 2, ...rutas(dir, 'uno') });
  await assert.rejects(() => generar({ inicial: 100, cantidad: 1, ...rutas(dir, 'dos') }), /solo puede indicarse/);
});

test('detiene un historial corrupto sin sobreescribirlo', async (t) => {
  const dir = await carpetaTemporal(t);
  const r = rutas(dir, 'error');
  await fs.writeFile(r.historial, '{"version":1,"historial":', 'utf8');
  const antes = await fs.readFile(r.historial, 'utf8');
  await assert.rejects(() => generar({ cantidad: 3, ...r }), /corrupto/);
  assert.equal(await fs.readFile(r.historial, 'utf8'), antes);
  assert.equal(await fs.readdir(dir).then((a) => a.some((n) => n.endsWith('.csv'))), false);
});

test('detecta alteracion manual mediante SHA-256', async (t) => {
  const dir = await carpetaTemporal(t);
  const r = rutas(dir, 'original');
  await generar({ cantidad: 3, ...r });
  const documento = JSON.parse(await fs.readFile(r.historial, 'utf8'));
  documento.historial.pop();
  await fs.writeFile(r.historial, JSON.stringify(documento), 'utf8');
  await assert.rejects(() => generar({ cantidad: 1, ...rutas(dir, 'posterior') }), /SHA-256/);
});

test('si falta historial pero existe marca, no reinicia los contadores', async (t) => {
  const dir = await carpetaTemporal(t);
  const r = rutas(dir, 'primero');
  await generar({ cantidad: 1, ...r });
  await fs.rm(r.historial);
  await assert.rejects(() => generar({ cantidad: 1, ...rutas(dir, 'segundo') }), /Falta el JSON/);
});

test('el bloqueo impide ejecutar dos procesos sobre el mismo historial', async (t) => {
  const dir = await carpetaTemporal(t);
  const r = rutas(dir, 'bloqueado');
  await fs.mkdir(`${r.historial}.lock`);
  await assert.rejects(() => generar({ cantidad: 2, ...r }), /candado/);
  await fs.rm(`${r.historial}.lock`, { recursive: true });
  const res = await generar({ cantidad: 2, ...r });
  assert.equal(res.registros.length, 2);
});

test('reexporta un lote sin modificar el historial', async (t) => {
  const dir = await carpetaTemporal(t);
  const r = rutas(dir, 'inicial');
  const inicial = await generar({ cantidad: 4, ...r });
  const antes = await fs.readFile(r.historial, 'utf8');
  const salida = path.join(dir, 'reexportado.csv');
  const reexportado = await exportarLote({ historial: r.historial, salida,
    lote: inicial.lote });
  assert.deepEqual(reexportado.registros, inicial.registros);
  assert.equal(await fs.readFile(salida, 'utf8'), await fs.readFile(r.salida, 'utf8'));
  assert.equal(await fs.readFile(r.historial, 'utf8'), antes);
});

test('CSV en Excel protege ceros iniciales y rechaza codigos invalidos', () => {
  const gtin_13 = '0000000000000';
  assert.equal(validarGTIN13(gtin_13), true);
  assert.ok(crearCSV([{ gtin_13 }], 'excel').includes('1,"=""0000000000000"""'));
  assert.throws(() => crearCSV([{ gtin_13: '0000000000001' }]), /invalido/);
});

test('ejecuciones simultaneas solo emiten codigos distintos', async (t) => {
  const dir = await carpetaTemporal(t);
  const operaciones = Array.from({ length: 4 }, (_, i) => lanzar([
    'generar', '--cantidad', '5', '--historial', 'historial.json',
    '--salida', `salida_${i}.csv`
  ], dir));
  const resultados = await Promise.all(operaciones);
  assert.ok(resultados.some((r) => r.codigo === 0));
  assert.ok(resultados.every((r) => r.codigo === 0 || /candado/.test(r.stderr)));
  const estado = await leerHistorial(path.join(dir, 'historial.json'));
  assert.equal(estado.historial.length, resultados.filter((r) => r.codigo === 0).length * 5);
  assert.equal(new Set(estado.historial.map((r) => r.gtin_13)).size, estado.historial.length);
});

test('un prefijo oficial de 12 digitos solo admite un GTIN', async (t) => {
  const dir = await carpetaTemporal(t);
  const parametros = { modo: 'oficial', prefijo: '750123456789', confirmarAutorizacion: true };
  const primera = await generar({ ...parametros, cantidad: 1, ...rutas(dir, 'unico') });
  assert.equal(primera.registros[0].referencia, '');
  assert.equal(primera.registros[0].gtin_13, formarGTIN13(parametros.prefijo, ''));
  await assert.rejects(() => generar({ ...parametros, cantidad: 1,
    ...rutas(dir, 'otro') }), /Disponibles: 0/);
});
